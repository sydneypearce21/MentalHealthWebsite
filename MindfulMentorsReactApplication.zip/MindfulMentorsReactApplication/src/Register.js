import React, { Component } from 'react';
import axios from 'axios';
import { Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';

class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: [],
        username: "",
        email: "",
        password: ""
    };
  }

// when component mounts, first thing it does is fetch all existing data in our db
// then we incorporate a polling logic so that we can easily see if our db has
// changed and implement those changes into our UI
componentDidMount() {
  this.getDataFromDb();
}

// never let a process live forever
// always kill a process everytime we are done using it
componentWillUnmount() {
  if (this.state.intervalIsSet) {
    clearInterval(this.state.intervalIsSet);
    this.setState({ intervalIsSet: null });
  }
}

getDataFromDb = () => {
  fetch('http://localhost:9000/testDB')
    .then((user) => user.json())
    .then((res) => this.setState({ user: res.user }));
};

putDataToDB = (username, email, password) => {
  axios.post('http://localhost:9000/testDB', {
    username: username,
    email: email,
    password: password,
  });
};

  render() {
  return (
      <>

    <h1>Create an account</h1>
    <Form action="/login" onSubmit={() => this.putDataToDB(this.state.username, this.state.email, this.state.password)}>
      <FormGroup>
        <Label for="username">Username</Label>
        <Input type="text" name="username" id="username" placeholder="Enter a Username" onChange={(e) => this.setState({ username: e.target.value })}/>
      </FormGroup>
      <FormGroup>
        <Label for="email">Email</Label>
        <Input type="email" name="email" id="email" placeholder="Enter your Email Address" onChange={(e) => this.setState({ email: e.target.value })}/>
      </FormGroup>
      <FormGroup>
        <Label for="password">Password</Label>
        <Input type="password" name="password" id="password" placeholder="Enter a Password" onChange={(e) => this.setState({ password: e.target.value })}/>
      </FormGroup>
      <FormGroup>
        <Button>Submit</Button>
      </FormGroup>
    </Form>

    <h4>Create an account to receive updates via our weekly newsletters!</h4>
    </>
  );
}
}

export default Register;