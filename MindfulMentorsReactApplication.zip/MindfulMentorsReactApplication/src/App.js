import React, { Component, useState } from 'react';
import Login from "./Login";
import { Link } from 'react-router-dom' ;
import { Container } from 'reactstrap';
import  MindfulMentors  from './Images/MindfulMentors.jpg';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  NavbarText
} from 'reactstrap';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dbResponse: ""
        };
    }

    callDB() {
        fetch("http://localhost:9000/testDB")
        .then(res => res.text())
        .then(res => this.setState({ dbResponse: res }))
        .catch(err => err);
    }

    componentDidMount() {
        this.callDB();
    }

    /* render() {
        return (
            <div className="App">
                <p className="App-intro">{this.state.apiResponse}</p>
                <p className="App-intro">{this.state.dbResponse}</p>
            </div>
        );
    } */
}

export default App;