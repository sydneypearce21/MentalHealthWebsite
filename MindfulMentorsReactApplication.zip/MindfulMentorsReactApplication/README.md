I have deleted the node_modules from the project. You must open to the:
MindfulMentorsReactApplication directory

and then run npm install, then you can run npm start.

In another cmd terminal, you must open to the:
MindfulMentorsReactApplication/api directory

In here you want to also npm start, as this creates the express.js connection to bridge between the client (React) and the DB (Mongo).

Main Pages to focus on if you are working on DB connection:
(Within MindfulMentorsReactApplication/src folder)
- Login.js
- Register.js

(Within MindfulMentorsReactApplication/api/routes folder
- testDB.js


The express in testDB runs on port 9000 and the React runs on 3000, this allows both to run locally at once (hence the need for 2 cmd terminals).

The DB connections in testDB.js are done using 'Mongoose'. This was recommended to me by Jal to be used with MongoDB

You shouldn't have to change any of the connection strings for Mongoose/MongoDB
These all should work on all of our computers, I allowed all IP's access to our Data Storage on Mongo for ease.

Just in case:
connect uri = "mongodb+srv://admin:admin@cluster0.rrda1.mongodb.net/MindfulMentorsDB?retryWrites=true&w=majority";

testDB.js uses a get and a post method
get is used obviously for grabbing data (used in Login.js)
post is (trying) to save data to the db (register.js)

In the cmd you are running the express api in, if you try to submit on the register or login pages within the webbrowser, you will see result json objects/response codes.
login responds with a 304 (no change, so it's not actually checking)
register responds with a 500 (server side error, so this must be within the express somewhere)